package com.petadota.foreverhome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForeverHomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
