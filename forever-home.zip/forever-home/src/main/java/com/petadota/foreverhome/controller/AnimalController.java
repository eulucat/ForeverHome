package com.petadota.foreverhome.controller;

import com.petadota.foreverhome.model.Animal;
import com.petadota.foreverhome.service.AnimalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/animais")

public class AnimalController {

    @Autowired
    private AnimalService animalService;

    // Página inicial (apresentação)
    @GetMapping
    public String paginaInicial() {
        return "animais";  // Retorna a página inicial
    }

    // Exibir lista de animais
    @GetMapping("/lista")
    public String listarAnimais(Model model) {
        List<Animal> animais = animalService.findAll();
        model.addAttribute("animais", animais);
        return "lista";  // Página que exibe os animais
    }

    // Formulário para criar um novo animal
    @GetMapping("/novo")
    public String exibirFormularioCriacao(Model model) {
        model.addAttribute("animal", new Animal());
        return "formAnimal";  // Página do formulário de criação
    }

 // Método para criar um novo animal
    @PostMapping("/novo")
    public String criarAnimal(@ModelAttribute Animal animal) {
        animalService.save(animal);
        return "redirect:/animais/lista";
    }

    // Método para atualizar um animal existente
    @PostMapping("/{id}")
    public String atualizarAnimal(@PathVariable Long id, @ModelAttribute Animal animal) {
        Animal existingAnimal = animalService.findById(id)
                .orElseThrow(() -> new RuntimeException("Animal não encontrado"));

        existingAnimal.setNome(animal.getNome());
        existingAnimal.setEspecie(animal.getEspecie());
        existingAnimal.setRaca(animal.getRaca());
        existingAnimal.setIdade(animal.getIdade());
        existingAnimal.setStatusAdocao(animal.getStatusAdocao());
        existingAnimal.setImagem(animal.getImagem());
        existingAnimal.setDescricao(animal.getDescricao());

        animalService.save(existingAnimal);
        return "redirect:/animais/lista";
    }



    // Formulário para editar um animal existente
    @GetMapping("/{id}/editar")
    public String exibirFormularioEdicao(@PathVariable Long id, Model model) {
        Animal animal = animalService.findById(id)
                .orElseThrow(() -> new RuntimeException("Animal não encontrado"));
        model.addAttribute("animal", animal);
        return "formAnimal";  // Página do formulário de edição
    }


    // Método para excluir um animal
    @GetMapping("/{id}/excluir")
    public String excluirAnimal(@PathVariable Long id) {
        animalService.deleteById(id);
        return "redirect:/animais/lista";  // Redireciona para a lista de animais após excluir
    }

 // Método para exibir o formulário de consulta
    @GetMapping("/consulta")
    public String consultaAnimalPorIdForm() {
        return "consulta-animal";
    }

    // Método para buscar o animal pelo ID
    @GetMapping("/consulta/{id}")
    public String consultaAnimalPorId(@RequestParam("id") Long id, Model model) {
        Optional<Animal> animalOpt = animalService.buscarAnimalPorId(id);

        if (animalOpt.isPresent()) {
            model.addAttribute("animal", animalOpt.get());
            return "detalhes-animal"; // Página que exibirá os detalhes do animal
        } else {
            model.addAttribute("mensagemErro", "Animal com ID " + id + " não encontrado.");
            return "consulta-animal";
        }
    }


    
}