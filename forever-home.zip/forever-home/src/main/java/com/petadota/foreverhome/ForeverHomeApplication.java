package com.petadota.foreverhome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication 
@ComponentScan (basePackages="com.petadota.foreverhome.controller," + "com.petadota.foreverhome.service")
public class ForeverHomeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForeverHomeApplication.class, args);
		System.out.println("Oie!");
	}

}

